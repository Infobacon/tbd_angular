(function(){
    angular.module('iServifast')
.controller('MainCtrl', function($scope){
$scope.Visible=false;
});
})();
